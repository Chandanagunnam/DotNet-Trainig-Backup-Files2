using System;
namespace SlowSolution
{
class Program
{
static void Main(string []args)
{
int n,i=0,result=0;
Console.WriteLine("Enter a Number:");
n=int.Parse(Console.ReadLine());
for(i=1;i<=n;i++)
        {
             result +=i;
Console.WriteLine(result+",");
        }
Console.WriteLine("Sum Number:{0}",result);
}
}
}