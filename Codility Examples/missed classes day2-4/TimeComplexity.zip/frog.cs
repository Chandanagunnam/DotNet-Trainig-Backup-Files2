using System;

namespace FrogJump
{
class Solution
{ 
public int solution(int X, int Y, int D)
{

int Len=Y-X;

if(Len%D==0)
{
return Len/D;
}
else
{
return (Len/D)+1;
}
}
}
}