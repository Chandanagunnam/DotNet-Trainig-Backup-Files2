using System;
namespace EfficientApproach
{
class Program
{

/*static int SumDigits(int x)
{
int sum=0;
while(x!=0)
{
sum+=x%10;
x=x/10;
}
return sum;
}
static int solution(int n)
{
int result=0;
for(int i=1;i<=n;i++)
{
result+=SumDigits(i);
}
return result;
}*/

static void Main(string []args)
{
/*int n,n1,n2,n3,n4;
n=5;
n1=328;
n2=999;
n3=1024;
n4=65999;
Console.WriteLine("Sum of : "+n+"is:"+Program.solution(n));
Console.WriteLine("Sum of : "+n1+"is:"+Program.solution(n1));
Console.WriteLine("Sum of : "+n2+"is:"+Program.solution(n2));
Console.WriteLine("Sum of : "+n3+"is:"+Program.solution(n3));
Console.WriteLine("Sum of : "+n4+"is:"+Program.solution(n4));*/
int n=0;
int result;
Console.WriteLine("Enter a Number");
n=int.Parse(Console.ReadLine());
result=(n*(n+1))/2;
Console.WriteLine(result); 
}
}
}