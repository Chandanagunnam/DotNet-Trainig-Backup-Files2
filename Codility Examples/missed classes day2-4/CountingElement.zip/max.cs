using System;
namespace BivalueLength
{
class Solution
{
public int solution(int[] A)
{
int maxlength=0;
if(A.Length==0) return 2;
for(int i=0;i<A.Length;i++)
{
int firstno=A[i];
int secondno=firstno;
for(int j=i+1;j<A.Length;j++)
{
int currentlen=j-i+1;
if(A[j]!=firstno && A[j]!=secondno)
{
if(secondno==firstno)
{
secondno=A[j];
}
else
{
break;
}
}
if(currentlen>maxlength)
{
maxlength=currentlen;
}
}
}
return maxlength;
}
}
class Program
{
static void Main(string []args)
{
Solution s=new Solution();
int []A={5,4,4,5,0,12};
int []A1={12,0,5,4,5,4};
int []A3={0,0,0,0,0};
int []A4={-1,-2,-3,-4,-5};
Console.WriteLine(s.solution(A));
Console.WriteLine(s.solution(A1));
Console.WriteLine(s.solution(A3));
Console.WriteLine(s.solution(A4));
}
}
}