using System;
using System.Collections.Generic;
using System.Linq;
class Arrayswaping
{
static void Main()
{
int[] A={1,2,3,4,5};
int [] B={11,22,33,44,55,66};

int n=A.Length;
int sum_a=A.Sum();
int sum_b=B.Sum();
int d=sum_b-sum_a;
if(d%2==1)
{
Console.WriteLine("swapping is not possible");
}
else
{
d=d/2;
Console.WriteLine("enter m value");
int m=int.Parse(Console.ReadLine());

for(int i=0;i<m;i++)
{
if (B[i]-d<=0 && B[i]-d <=m)
{
int temp=A[i];
A[i]=B[i];
B[i]=temp;
}

else
{
Console.WriteLine("not swapped");
}
for(int k=0;k<A.Length;k++)
{
Console.WriteLine(A[k]);
}
Console.WriteLine("--------");
for(int k=0;k<B.Length;k++)
{
Console.WriteLine(B[k]);
}
}


}
}
}