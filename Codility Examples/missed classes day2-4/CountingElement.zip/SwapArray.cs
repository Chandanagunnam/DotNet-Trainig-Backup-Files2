using System;

class Program
{
static void Main(string [] args)
{
int [] A = {1,2,3,4,5};
int [] B = {30,40,50,60,70};
if(A.Length != B.Length)
{
Console.WriteLine("Swapping not Possible");
}
else 
{
int []Temp = new int [A.Length];
int j = 0;
foreach (var item in A)
{
Temp[j++]= item;
}
int i =0; 
foreach (var item in B )
{
A[i++] = item;
}
int k =0; 
foreach(var item in Temp)
{
B[k++] = item;
}
}
for (int i=0; i<A.Length;i++)
{
Console.WriteLine(A[i]);
}
Console.WriteLine("---------------------------------------");
for (int i=0; i<B.Length;i++)
{

Console.WriteLine(B[i]);
}
}
}