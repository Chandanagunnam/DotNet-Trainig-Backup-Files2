using System;
namespace MergingArrayEg
{
class Mergerray
{
static void Main(String []args)
{
int []temp=new int[4];
int cnt=0;

Console.WriteLine("please enter temp (4) elements");
for(int i=0;i<temp.Length;i++)
{
temp[i]=int.Parse(Console.ReadLine());
}
foreach(int t in temp)
{
if(t<0)
{
cnt++;
}
}
Console.WriteLine("negative temperature values are:"+cnt);

}
}
}