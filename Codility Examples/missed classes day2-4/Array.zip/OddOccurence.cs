using System;
using System.Collections.Generic;

namespace oddoccurences
{
class Solution
{
public int solution(int[]A)
{
Dictionary<int,int>hmap= new Dictionary<int,int>();
for(int i=0;i<A.Length;i++)
{
if(hmap.ContainsKey(A[i]))
{
int val=hmap[A[i]];
hmap.Remove(A[i]);
hmap.Add(A[i],val+1);
}
else
{
hmap.Add(A[i],1);
}
}
foreach(KeyValuePair<int, int> k in hmap)
{
if(k.Value%2!=0)
{
return k.Key;
}

}
Console.WriteLine("There is no odd Occurence");
return -1;
}
}
class Program
{
static void Main()
{
Solution s = new Solution();
int [] arr= {1,2,3,1,2,3};
int [] arr1= {6,12,3,6,2,3};
Console.WriteLine(s.solution(arr));
Console.WriteLine("Odd Occurence is "+s.solution(arr1));
}
}
}