using System;
namespace ArrayExample
{
class RepeatArrayElements
{
static void Main(string []args)
{
string []arr=new string[3];
for(int i=0;i<arr.Length;i++)
{
arr[i]="Hello";
}
Console.WriteLine("Elements in Array:");
foreach(var a in arr)
{
Console.WriteLine(a);
}
}
}
}