using System;
namespace ArrayReverse
{
class Solution
{
public int[] solution(int []A,int K)
{
if(A.Length==0)
{
return A;
}
K=K%A.Length;
System.Array.Reverse(A);
System.Array.Reverse(A,0,K);
System.Array.Reverse(A,K,A.Length-K);
return A;1
}

static void Main()
{
int [] arr1;
Solution s=new Solution();
int[] number={1,2,3,4,5};
Console.WriteLine("Enter Starting Number to Cyclic Rotation");
int n=int.Parse(Console.ReadLine());
Console.WriteLine("------------------------------------------------");
arr1=s.solution(number,n);
foreach(var item in arr1)
{
Console.WriteLine(item);
}
}
}
}