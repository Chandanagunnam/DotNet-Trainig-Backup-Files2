using System;
namespace ArrayExample1
{
class solution
{
static void Main(string[]args)
{
int i;
string []products={"Bread","Jam","Cheese","Butter","Eggs"};
Console.WriteLine("Number of Elements in Array:"+products.Length);
Console.WriteLine("Get Products Based on Index Number\n{0},{1},{2}",products[0],products[2],products[4]);
products[1]="Mixed Fruits Jam";
for(i=0;i<products.Length;i++)
Console.WriteLine(products[i]);
}
}
}