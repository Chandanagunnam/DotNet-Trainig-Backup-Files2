using System;
namespace Arrayreverseexample
{
class Arrayreverse
{
static void Main(String []args)
{
string []products={"Bread","Cheese","Butter","Jam","Egg"};
for(int i=0;i<products.Length;i++)
Console.WriteLine(products[i]);
Console.WriteLine("----------------------------------------------");
//assiging products to reverse products array
string []reverseproducts=products;
Array.Reverse(products);
for(int i=0;i<reverseproducts.Length;i++)
Console.WriteLine(products[i]);

Console.WriteLine("----------------------------------------------");
//method 2

int[]arr={7,6,5,4,3,2,1};
int temp,start=0,end=arr.Length-1;
while(start<end)
{
temp=arr[start];
arr[start]=arr[end];
arr[end]=temp;
start++;
end--;
}
for(int i=0;i<arr.Length;i++)
Console.WriteLine(arr[i]);
}
}
}