using System;
namespace ArrayExample
{
class Solution
{
static void Main(string []args)
{
int []arr1=new int[4];
int []arr2=new int[4];
int []arr3=new int[8];
int j=0;
Console.WriteLine("Enter Arr1 Elements:");
for(int i=0; i<arr1.Length;i++)
{
  arr1[i]=int.Parse(Console.ReadLine());
}

Console.WriteLine("Enter Arr2 Elements:");

for(int i=0; i<arr2.Length;i++)
{
arr2[i]=int.Parse(Console.ReadLine());
}
//Merge Arr1 and Arr2 into Arr3
for(int i=0;i<arr1.Length;i++)
{
arr3[j++]=arr1[i];
}
for(int i=0;i<arr2.Length;i++)
{
arr3[j++]=arr2[i];
}
Console.WriteLine("Merged Array:");
foreach(var a in arr3)
{
Console.Write(" ");
Console.Write(a);
}
}
}
}