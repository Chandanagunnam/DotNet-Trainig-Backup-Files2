using System;
namespace BusReservation
{
class Busreservation
{
static void Main()
{
int [] seats = new int[25];
string ans="Yes";
Console.WriteLine("Welcome to Bus Reservation");
Console.WriteLine("------------------------------------------------------");
while(ans=="Yes")
{
Console.WriteLine("Enter the Number of Tickets to be Booked:");
int Numberofseats=int.Parse(Console.ReadLine());
if(Numberofseats>25)
{
Console.WriteLine("Bus Capacity is 25");
}
else
for(int i=0; i<Numberofseats; i++)
{
Console.WriteLine("Enter the Seat Number:");
int SeatNumber=int.Parse(Console.ReadLine());
if(SeatNumber==0)
{
Console.WriteLine("You cannot Book Driver seat!!!!");
Console.WriteLine("Please Choose Different seat");
SeatNumber=int.Parse(Console.ReadLine());
seats[SeatNumber]=1;
}
else
{
while(seats[SeatNumber]==1)
{
Console.WriteLine("This seat is already Booked");
Console.WriteLine("Please Choose Different seat");
SeatNumber=int.Parse(Console.ReadLine());
}
seats[SeatNumber]=1;
}
}
Console.WriteLine("Do you want to book more tickets(Yes or No):");
ans=Console.ReadLine();
if(ans=="No")
{
Console.WriteLine("--------------Seat Arrangement------------------");
foreach(int s in seats)
{
Console.Write(s);
Console.Write(" ");
}
Console.WriteLine("Seat Booked......Enjoy Your Journey");
}
}
}
}
}